import { MARQUEE_INFO } from '../../constants/poolData.js';
import styles from './Designer.module.css';

export function StepSummary({ state, actions }) {
  const { form, poolType, photos, messages, submitted } = state;
  const { submitDesign, resetAll, goBack } = actions;

  if (submitted) return <ConfirmationScreen form={form} onReset={resetAll} />;

  const assistantCount = messages.filter((m) => m.role === 'assistant').length;

  return (
    <div className={styles.stepContent}>
      {/* Hero card */}
      <div className={styles.summaryHero}>
        <div className={styles.summaryHeroIcon}>🏊‍♀️</div>
        <h2 className={styles.summaryHeroTitle}>{form.name}'s Custom Pool</h2>
        <p className={styles.summaryHeroAddr}>{form.address}</p>
        {poolType && (
          <span className={styles.summaryHeroBadge}>
            {poolType === 'fiberglass' ? 'Fiberglass Pool' : 'Vinyl-Liner Pool'}
          </span>
        )}
      </div>

      {/* Contact */}
      <div className={styles.summaryGrid2}>
        {[['Email', form.email], ['Phone', form.phone]].map(([l, v]) => (
          <div key={l} className={styles.summaryInfoCell}>
            <div className={styles.summaryInfoLabel}>{l}</div>
            <div className={styles.summaryInfoValue}>{v}</div>
          </div>
        ))}
      </div>

      {/* Photos */}
      {photos.length > 0 && (
        <div className={styles.summarySection}>
          <p className={styles.summarySectionTitle}>Site Photos ({photos.length})</p>
          <div className={styles.summaryPhotoRow}>
            {photos.map((p, i) => (
              <img key={i} src={p.url} alt="" className={styles.summaryPhoto} />
            ))}
          </div>
        </div>
      )}

      {/* Transcript */}
      <div className={styles.summarySection}>
        <p className={styles.summarySectionTitle}>
          Design Consultation ({assistantCount} recommendation{assistantCount !== 1 ? 's' : ''})
        </p>
        <div className={styles.summaryTranscript}>
          {messages.map((m, i) => (
            <div key={i} className={styles.summaryMsg}>
              <div
                className={styles.summaryMsgAvatar}
                style={{ background: m.role === 'assistant' ? 'linear-gradient(135deg,var(--theme-color),var(--theme-color3))' : 'var(--smoke-color2)' }}
              >
                <span style={{ color: m.role === 'assistant' ? '#fff' : 'var(--theme-color)' }}>
                  {m.role === 'assistant' ? 'M' : form.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <div className={styles.summaryMsgRole}>
                  {m.role === 'assistant' ? 'Marquee Designer' : form.name.split(' ')[0]}
                </div>
                <p className={styles.summaryMsgText}>{m.content}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button className={`th-btn ${styles.submitBtn}`} onClick={submitDesign}>
        Submit — Request My Free Estimate
      </button>
      <p className={styles.submitNote}>
        A Marquee specialist will contact you within 24 hours · {MARQUEE_INFO.phone}
      </p>
      <button className={styles.backLink} onClick={goBack}>← Continue Designing</button>
    </div>
  );
}

function ConfirmationScreen({ form, onReset }) {
  const firstName = form.name.split(' ')[0];
  return (
    <div className={styles.stepContent} style={{ textAlign: 'center', paddingTop: 48, paddingBottom: 48 }}>
      <div className={styles.confirmIcon}>✅</div>
      <h2 className={styles.confirmTitle}>Design Submitted!</h2>
      <p className={styles.confirmDesc}>
        Thank you, <strong>{firstName}</strong>! A Marquee Pools specialist will contact you within
        24 hours to discuss your project and schedule a free on-site consultation.
      </p>
      <div className={styles.confirmContact}>
        <a href={`tel:${MARQUEE_INFO.phone.replace(/\D/g, '')}`}>
          📞 {MARQUEE_INFO.phone}
        </a>
        <a href={`mailto:${MARQUEE_INFO.email}`}>
          ✉ {MARQUEE_INFO.email}
        </a>
      </div>
      <p className={styles.confirmLicense}>
        Marquee Pools & Service, Inc. · Fairfield, CT · Est. 1987 · Fully Licensed & Insured
      </p>
      <button className={styles.backLink} onClick={onReset}>Start a New Design</button>
    </div>
  );
}
