import { SYSTEM_PROMPT } from '../constants/poolData.js';

const USE_PROXY    = import.meta.env.VITE_USE_PROXY === 'true';
const PROXY_URL    = import.meta.env.VITE_PROXY_ENDPOINT || '/wp-json/marquee-pools/v1/design-chat';
const API_KEY      = import.meta.env.VITE_ANTHROPIC_API_KEY;
const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';

/**
 * Send a conversation to Claude and return the assistant's reply text.
 *
 * @param {Array<{role: 'user'|'assistant', content: string}>} messages
 * @returns {Promise<string>}
 */
export async function chatWithDesigner(messages) {
  if (USE_PROXY) {
    return callProxy(messages);
  }
  return callDirect(messages);
}

// ── Direct browser call (dev / sandbox only) ─────────────────────────────────
async function callDirect(messages) {
  if (!API_KEY) {
    throw new Error(
      'Missing VITE_ANTHROPIC_API_KEY. Copy .env.example → .env.local and add your key.'
    );
  }

  const res = await fetch(ANTHROPIC_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || `API error ${res.status}`);
  }

  const data = await res.json();
  return data.content?.map((b) => b.text || '').join('') || '';
}

// ── WordPress REST proxy call (production) ────────────────────────────────────
// The PHP plugin receives this, adds the secret key server-side, and proxies to Anthropic.
async function callProxy(messages) {
  const res = await fetch(PROXY_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.message || `Proxy error ${res.status}`);
  }

  const data = await res.json();
  return data.reply || '';
}
